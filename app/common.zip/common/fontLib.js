let fonts = 
{
	regFont:
	{
		ios: 'Open Sans',
		android: 'OpenSans-Regular',
	},

	lhtFont:
	{
		ios: 'OpenSans-Light',
		android: 'OpenSans-Light',		
	},

};

export {fonts as fnt};