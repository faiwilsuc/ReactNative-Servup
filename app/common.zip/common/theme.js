let themeColor = 
{
	wind: '#00833c',
	windSplashBackground: '#4357F4',
	windSplash: require('../login/images/Servup_logo.png'),
	windLogo: require('../login/images/telco_logo.png'),


// facebook colors '#4c669f', '#3b5998', '#192f6a'	
//	wind: '#ec7c23',
//	windSplashBackground: 'black',
//	windSplash: require('../../Scenes/images/wind-logo.png'),
	
//	wind: '#ec7c23',
//	windSplashBackground: 'black',
//	windSplash: require('../../Scenes/images/wind-logo.png'),

};

let titleArea = 
{
	ios: 40,
	android: 0,
};

export {themeColor as themeColor};
export {titleArea as titleArea};